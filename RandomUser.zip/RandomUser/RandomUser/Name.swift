//
//  Name.swift
//  RandomUser
//
//  Created by Robert Steed on 2/27/23.
//

import Foundation
struct Name {
    var name: String
    
}
