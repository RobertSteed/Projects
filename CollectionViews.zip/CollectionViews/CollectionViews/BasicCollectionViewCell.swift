//
//  BasicCollectionViewCell.swift
//  CollectionViews
//
//  Created by Brayden Lemke on 1/19/23.
//

import UIKit

class BasicCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
    
    
}
