//
//  ViewController.swift
//  Poker Hands
//
//  Created by Robert Steed on 2/20/23.
//

import UIKit

class ViewController: UIViewController {
    
    enum Suit {
        case spades
        case hearts
        case diamonds
        case clubs
    }
    
    enum PlayingCardValue: Int {
        case two = 2, three, four, five, six, seven, eight, nine, ten
        case jack, queen, king, ace
        
        var description: String {
            switch self {
            case .jack:
                return "J"
            case .queen:
                return "Q"
            case .king:
                return "K"
            case .ace:
                return "A"
            default:
                return String(rawValue)
            }
        }
    }
    
    struct Card {
        let rank: PlayingCardValue
        let suit: Suit
        
        var description: String {
            return "\(rank.description)\(suit)"
        }
    }
    
    func checkHand(_ cards: [Card]) -> String {
        let sortedCards = cards.sorted { $0.rank.rawValue < $1.rank.rawValue }
        let cardValue = sortedCards.map { $0.rank }
        let suits = sortedCards.map { $0.suit }
        
        if Set(suits).count == 1 {
            if cardValue == [.ten, .jack, .queen, .king, .ace] {
                return "Royal Flush"
            } else if Set(cardValue).count == 1 {
                return "Straight Flush"
            } else if let maxRank = cardValue.rawValue.max(), maxRank.rawValue - cardValue.rawValue.min()!.rawValue == 4 {
                return "Straight Flush"
            } else {
                return "Flush"
            }
        } else if Set(cardValue).count == 2 {
            let firstCardValueCount = cardValue.filter { $0 == cardValue[0] }.count
            let secondCardValueCount = cardValue.filter { $0 == cardValue[1] }.count
            
            if firstCardValueCount == 4 || secondCardValueCount == 4 {
                return "Four of a Kind"
            } else {
                return "Full House"
            }
        } else if Set(cardValue).count == 3 {
            let rankCounts = cardValue.map { rank in
                return cardValue.filter { $0 == rank }.count
            }
            
            if rankCounts.contains(3) {
                return "Three of a Kind"
            } else {
                return "Two Pair"
            }
        } else if Set(cardValue).count == 4 {
            return "One Pair"
        } else {
            return "High Card"
        }
    }
    
//    let cards = [
//        Card(rank: .two, suit: .hearts),
//        Card(rank: .seven, suit: .clubs),
//        Card(rank: .ace, suit: .spades),
//        Card(rank: .five, suit: .diamonds),
//        Card(rank: .three, suit: .hearts)
//    ]
    
  
}
