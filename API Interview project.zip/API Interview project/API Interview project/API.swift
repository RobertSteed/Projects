//
//  API.swift
//  API Interview project
//
//  Created by Robert Steed on 3/3/23.
//

import Foundation

struct API {
    static var url = "https://randomuser.me/api/"
}
